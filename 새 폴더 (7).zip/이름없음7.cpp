#include<stdio.h>
int main()
{
	int a;
	int b;
	int c;
	scanf("%d",&a);
	b = a % 100 / 10;
	c = a % 10;
	a = a / 100;
	printf("%d+%d+%d = %d\n%d*%d*%d = %d",a , b, c, a+b+c,a , b, c, a*b*c);
	return 0;
}
