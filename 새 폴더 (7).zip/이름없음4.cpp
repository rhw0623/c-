#include<stdio.h>
int main()
{
	int a = 70, b = 7;
	float f1 = 77.0, f2 = 7.0;
	
	printf("%d\n", a/b);
	printf("%f\n", f1/b);
	printf("%f\n", a/f2);
	printf("%f\n", f1/f2);
}
