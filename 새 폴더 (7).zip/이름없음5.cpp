#include<stdio.h>
int main()
{
	int a;
	int b;
	int c;
	scanf("%d",&a);
	b = a % 10;
	a = a / 10;
	printf("%d + %d = %d", a , b , a+b);
}
