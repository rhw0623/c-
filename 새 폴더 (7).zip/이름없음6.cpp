#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	srand(time(NULL));
	int a;
	a = rand()%89 + 10 ;

	printf("%d",a);
}
