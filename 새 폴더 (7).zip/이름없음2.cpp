#include<stdio.h>
int main()
{
	printf("%d\n", 10/3);
	printf("%d\n", 10/3.0);
	printf("%f\n", 10/3.0);
}
