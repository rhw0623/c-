#include<stdio.h>
int main()
{
	int grade = 2;
	int classs = 4;
	int number = 5;
	
	printf("%d�г� %d�� %d��", grade,classs,number);
	return 0;
}
