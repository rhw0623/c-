#include<stdio.h>

int main()
{
	int A;
	int B;
	int C;
	scanf("%d %d",&A, &B);
	scanf("%d", &C);
	if(C + B<59)
	{
		printf("%d %d", A, B+C);
	}
	else if(C + B >= 59)
	{
		A = A+ (C+B)/60;
		B = (C+B)%60;
		if(A>=24)
		{
			A = A%24;
			printf("%d %d", A, B);
		}
	
	}
	
}

