#include<stdio.h>

int main()
{
	int a, b;
	
	a = 23;
	b = 24;
	printf("%d\n", a > b);
	printf("%d\n", a < b); 
}

