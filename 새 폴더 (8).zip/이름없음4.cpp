#include<stdio.h>

int main()
{
	int a = 0; 
	int b = 0;
	scanf("%d %d", & a, &b);
	printf("%d+%d = %d\n%d-%d = %d\n%d*%d = %d\n%d/%d = %d ", a, b, a+b, a, b, a-b, a, b, a*b, a, b, a/b);
}
