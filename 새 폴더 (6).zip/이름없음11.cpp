#include<stdio.h>
int main()
{
	char a;
	scanf("%c",&a);
	printf("%c",a);
	return 0;
}
