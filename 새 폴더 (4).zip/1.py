p = 5
for i in range(3, 35, 2):
     p += 2
print(p)
