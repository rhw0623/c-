#include<stdio.h>

int main()
{
	printf("ABCDEFG\n1234567");
	printf("\n\n");
	printf("abcdefg\r1234");
	return 0;
}
