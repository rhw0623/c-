#include<stdio.h>
int main()
{
	printf("|\\_/|\n|q p|   /}\n( 0 )\"\"\"\\ \n||_/=\\__|");
	return 0;
}


