#include<stdio.h>
int main()
{
	printf("%%Solar Tracking System%%\n\\Smart Devices\\\n\"Matrix\"\n\'Hello Robot\'");
	return 0; 
 } 
