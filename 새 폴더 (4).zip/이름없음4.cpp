#include<stdio.h>
int main()
{
	printf("\\    /\ \\ \n )  ( ')\n(  /  )\n \\(__)|\n");
	return 0;
}
