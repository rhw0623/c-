#include<Stdio.h>
int main()
{
	int sum=0,min=100,input;
	for(int i=1; i<=4; i++)
	{
		scanf("%d",&input);
		if(input%2==1)
		{
			sum = sum + input;
			if(min>input)
			{
				min = input;
			}
		}
	}
	printf("%d\n%d",sum,min);
	
}
