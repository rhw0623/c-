#include<stdio.h>
int main()
{
	int a = 10;
	
	a--;
	printf("a = %d\n", a);
	--a;
	printf("a = %d\n", a);
}
