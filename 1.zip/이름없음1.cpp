#include<stdio.h>
int main()
{
	int a = 10;
	
	a++;
	a++;
	printf("a = %d\n", a);
	++a;
	++a;
	printf("a = %d\n", a);
}
