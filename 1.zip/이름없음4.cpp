#include<stdio.h>
int main()
{
	int i = 0;
	int n;
	scanf("%d",&n);
	while(i < n)
	{
		i++;
		if(i%2==0)
		{
			printf("%d ",i*-1);
			continue;
		}
		printf("%d ",i);
	}
	return 0;
}
	
	
