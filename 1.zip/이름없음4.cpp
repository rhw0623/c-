#include<stdio.h>
int main()
{
	int a = 20;
	
	a = a+4;
	printf("a = %d\n", a);
	a = a/2;
	printf("a = %d\n", a);
	a = --a;
	printf("a = %d\n", a);
	a = a;
	printf("a = %d\n", a);
}
