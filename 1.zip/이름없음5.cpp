#include<stdio.h>
int main()
{
	int n,sum;
	scanf("%d", &n);
	
	while(n>0)
	{
		printf("%d ", n%10);
		sum = sum +n %10;
		n/=10;
	}
	printf("\n�� : %d", sum);
	return 0;
}
	
	
