#include<stdio.h>
int main()
{
	int sum,i = 1;
	for(i; i<=1000; i++)
	{
		if(i%3==0)
		{
			printf("%d ",i*-1);
			sum = sum-i;
		}
		else
		{
			printf("%d ",i);
			sum=sum+i;
		}
	}
	printf("\n%d",sum);
}
