#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	int n;
	srand(time(NULL));
	n = (rand() % 45)+1;
	printf("%d ",n);
	n = (rand() % 45)+1;
	printf("%d ",n);
	n = (rand() % 45)+1;
	printf("%d ",n);
	n = (rand() % 45)+1;
	printf("%d ",n);
	n = (rand() % 45)+1;
	printf("%d ",n);
	n = (rand() % 45)+1;
	printf("%d ",n);
	return 0;
}
