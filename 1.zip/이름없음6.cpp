#include<stdio.h>
int main()
{
	int n,count=0;
	scanf("%d", &n);
	printf("%d��",n);
	while(n>0)
	{
		count++;
		n/=10;
	}
	printf("%d�ڸ����Դϴ�",count);
}
	
	
