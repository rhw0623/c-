#include<stdio.h>
int main()
{
	int a; 
	scanf("%d",&a);
	if(12%a==0&&30%a==0)
	{
		printf("�����");
	}
	else
	{
		printf("x");
	 } 
}

