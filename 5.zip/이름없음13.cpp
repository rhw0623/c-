#include<stdio.h>
int main()
{
	int n,o = 0,t = 0;
	scanf("%d", &n);
	
	for (int i = 6; i<=n; i+=6 )
	{
		o += 1;
		t = i+t;
		printf("%d ", i);	
	}
	printf("\n����:%d\n��:%d",o,t);
	return 0;
}
