#include<stdio.h>
int main()
{
	int i;
	
	for (i = 100; i>=0; i -= 100)
	{
		printf("i = %d\n", i);
	}
}
