#include<stdio.h>
int main()
{
	int a,b,c,d,sum = 0;
	scanf("%d", &a);
	scanf("%d", &b);
	for(int i = 1; i<=b; i++)
	{
		scanf("%d %d", &c, &d);
		sum = sum + (c*d);
	}
	if(a == sum)
	{
		printf("YES");
	}
	else
	{
		printf("NO");
	}
}
