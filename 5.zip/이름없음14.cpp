#include<stdio.h>
int main()
{
	float n = 160;
	
	for (int i = 1; i<=9; i++ )
	{
		n = n/2;
		
	}
	printf("9��°:%f\n",n);	
	return 0;
}
